import os
import json
from dataclasses import dataclass, fields

DEFAULT_SETTINGS_PATH = os.path.join(os.path.dirname(__file__), "settings.json")

@dataclass
class AppSettings:
    def __post_init__(self):
        self._on_change_callback = None  # 안전한 콜백 처리

    @classmethod
    def load_from_json(cls, path=DEFAULT_SETTINGS_PATH):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return cls()

        default = cls()
        for field in fields(cls):
            if field.name not in data:
                data[field.name] = getattr(default, field.name)
        return cls(**data)

    def get(self, key, default=None):
        return getattr(self, key, default)

    def set(self, key, value):
        setattr(self, key, value)

    def save_to_json(self, path=DEFAULT_SETTINGS_PATH):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        data_to_save = {field.name: getattr(self, field.name) for field in fields(self)}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data_to_save, f, indent=4, ensure_ascii=False)

        if self._on_change_callback:
            self._on_change_callback()

    def set_on_change_callback(self, callback):
        self._on_change_callback = callback
